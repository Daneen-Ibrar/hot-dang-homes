// pages/[...slug].js
import React from 'react';
import client from '../client';
import { gql } from '@apollo/client';
import Navbar from '../components/Navbar';
import { JSDOM } from 'jsdom';
import MyAccountPage from '../components/myAccount'; // Import the MyAccountPage component
import SellYourPropertyPage from 'components/SellYourPropertyPage';
import Contact from '../components/Contact'
import Search from 'components/Search';

// Function to parse HTML content using jsdom
const parseHTML = (htmlContent) => {
  const { window } = new JSDOM('');
  const parser = new window.DOMParser();
  const doc = parser.parseFromString(htmlContent, 'text/html');
  return doc;
};

// Function to parse the HTML content and apply appropriate classes and padding
const renderContent = (content) => {
  const doc = parseHTML(content);
  const elements = doc.body.childNodes;

  return Array.from(elements).map((element, index) => {
    if (element.nodeType === 3) {
      // If it's a text node, render it as plain text
      return (
        <div key={index} className="mt-8">
          <p className="font-body text-left">{element.textContent}</p>
        </div>
      );
    } else {
      // If it's an element node, render it with its tagName
      let className = '';
      switch (element.tagName) {
        case 'H1':
          className = 'font-heading text-4xl mb-3';
          break;
        case 'H2':
          className = 'font-heading text-5xl mb-3';
          break;
        case 'H3':
          className = 'font-heading text-6xl mb-3';
          break;
        case 'P':
          className = 'font-body mb-3';
          break;
        default:
          className = 'font-body mb-3';
      }
      return (
        <div key={index} className="mt-3">
          {React.createElement(element.tagName.toLowerCase(), {
            className: className + ' text-left',
            dangerouslySetInnerHTML: { __html: element.innerHTML },
          })}
        </div>
      );
    }
  });
};

const GuidePage = ({ content, slug }) => {
  const showButton = ['guide-to-buying', 'guide-to-selling', 'selling', 'buying'].includes(slug);

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <div className="container mx-auto p-3.5 max-w-screen-lg flex-grow">
        {renderContent(content)}
      </div>
      {showButton && (
        <div className="flex flex-col items-center mb-8">
          <h1 className="font-heading text-5xl mb-4">Searching for your dream home?</h1>
          <a href="/buying/all-properties" className="font-body font-bold bg-pink-500 text-white px-4 py-2 rounded hover:bg-pink-600 mt-3">
            VIEW ALL PROPERTIES
          </a>
        </div>
      )}
    </div>
  );
};

export default function Page({ content, slug, username }) {
  if (slug === 'my-account') {
    return <MyAccountPage username={username} />;
  }
  if (slug === 'sell-your-property') {
    return <SellYourPropertyPage />;
  }
  if (slug === 'contact-us') {
    return <Contact />;
  }
  if (slug === 'all-properties') {
    return <Search />;
  }
  return <GuidePage content={content} slug={slug} />;
}

export async function getStaticProps({ params }) {
  const uri = `/${params.slug.join('/')}/`;
  try {
    const { data } = await client.query({
      query: gql`
        query PageByUri($uri: String!) {
          nodeByUri(uri: $uri) {
            ... on Page {
              id
              content
              slug
            }
          }
        }
      `,
      variables: { uri },
    });

    if (!data || !data.nodeByUri) {
      return {
        notFound: true,
      };
    }

    return {
      props: {
        content: data.nodeByUri.content,
        slug: data.nodeByUri.slug,
      },
      revalidate: 10,
    };
  } catch (error) {
    console.error('Error fetching data:', error);
    return {
      notFound: true,
    };
  }
}

export async function getStaticPaths() {
  try {
    const { data } = await client.query({
      query: gql`
        query AllPagesQuery {
          pages {
            nodes {
              uri
            }
          }
        }
      `
    });

    const paths = data.pages.nodes
      .filter(page => page.uri !== '/')
      .map(page => ({
        params: {
          slug: page.uri.substring(1, page.uri.length - 1).split('/')
        },
      }));

    return {
      paths,
      fallback: 'blocking',
    };
  } catch (error) {
    console.error('Error fetching paths:', error);
    return {
      paths: [],
      fallback: 'blocking',
    };
  }
}

