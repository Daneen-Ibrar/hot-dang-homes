// pages/_app.js
import "../styles/globals.css";
import { config } from "@fortawesome/fontawesome-svg-core";
import "@fortawesome/fontawesome-svg-core/styles.css";
import { useState, useEffect } from 'react';
import LoginPopup from '../components/loginPopup';
import {ThemeProvider, BaseStyles} from '@primer/react'

config.autoAddCss = false;
a
function MyApp({ Component, pageProps }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');

  useEffect(() => {
    const loggedIn = localStorage.getItem('loggedIn');
    if (loggedIn === 'true') {
      const user = JSON.parse(localStorage.getItem('user'));
      setUsername(user.username);
      setIsAuthenticated(true);
    } else {
      setIsAuthenticated(false);
    }
  }, []);

  const handleLogin = (username) => {
    setUsername(username);
    setIsAuthenticated(true);
    localStorage.setItem('loggedIn', 'true');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUsername('');
    localStorage.removeItem('loggedIn');
    localStorage.removeItem('user');
    window.location.href = '/'; // Redirect to the homepage
  };

  return (
    <>
    <ThemeProvider> 
    <BaseStyles>
    <Component {...pageProps} username={username} onLogout={handleLogout} />
    {!isAuthenticated && <LoginPopup onLogin={handleLogin} />}
    </BaseStyles>
    </ThemeProvider>
     
    </>
  );
}

export default MyApp;