import { gql } from "@apollo/client";
import client from '../client'; // Ensure this path is correct
import { ApolloProvider } from '@apollo/client';
import { BlockRenderer } from "../BlockRenderer";

export default function Home({ content }) {
  return (
    <ApolloProvider client={client}>
      <div>
        <BlockRenderer content={content} />
      </div>
    </ApolloProvider>
  );
}

export async function getStaticProps() {
  try {
    const { data } = await client.query({
      query: gql`
        query HomePageQuery {
          nodeByUri(uri: "/" ) {
            ... on Page {
              id
              content
            }
          }
        }
      `
    });

    if (!data || !data.nodeByUri) {
      return {
        notFound: true,
      };
    }

    return {
      props: {
        content: data.nodeByUri.content,
      },
      revalidate: 1, // In seconds, adjust accordingly for ISR (Incremental Static Regeneration)
    };
  } catch (error) {
    console.error("Error fetching home page content:", error);
    return {
      notFound: true,
    };
  }
}
 